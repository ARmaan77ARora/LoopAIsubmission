const express = require('express');
const { v4: uuidv4 } = require('uuid');
const app = express();
const PORT = 5000;

const dataStore = require('./services/dataStore');
const queueManager = require('./services/queueManager');

app.use(express.json());

app.post('/ingest', (req, res) => {
  const { ids, priority } = req.body;

  if (!ids || !Array.isArray(ids) || !priority) {
    return res.status(400).json({ error: 'Invalid input format' });
  }

  const ingestionId = uuidv4();
  dataStore.createIngestion(ingestionId, ids, priority);
  queueManager.enqueueIngestion(ingestionId);

  res.json({ ingestion_id: ingestionId });
});

app.get('/status/:ingestionId', (req, res) => {
  const ingestionId = req.params.ingestionId;
  const status = dataStore.getIngestionStatus(ingestionId);

  if (!status) {
    return res.status(404).json({ error: 'Ingestion ID not found' });
  }

  res.json(status);
});

queueManager.startProcessing();

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

module.exports = app;