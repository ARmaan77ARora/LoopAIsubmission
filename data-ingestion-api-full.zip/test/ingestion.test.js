const chai = require('chai');
const chaiHttp = require('chai-http');
const app = require('../server');
const { expect } = chai;

chai.use(chaiHttp);

describe('Data Ingestion API Tests', function() {
  this.timeout(30000);

  let ingestionId;

  it('should ingest data successfully', (done) => {
    chai.request(app)
      .post('/ingest')
      .send({ ids: [1, 2, 3, 4, 5], priority: 'HIGH' })
      .end((err, res) => {
        expect(res).to.have.status(200);
        expect(res.body).to.have.property('ingestion_id');
        ingestionId = res.body.ingestion_id;
        done();
      });
  });

  it('should fetch ingestion status', (done) => {
    chai.request(app)
      .get(`/status/${ingestionId}`)
      .end((err, res) => {
        expect(res).to.have.status(200);
        expect(res.body).to.have.property('status');
        done();
      });
  });
});