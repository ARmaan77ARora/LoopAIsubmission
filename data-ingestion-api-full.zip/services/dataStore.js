const { v4: uuidv4 } = require('uuid');

let ingestions = {};

function createIngestion(ingestionId, ids, priority) {
  const batches = [];
  let batchSize = 3;

  for (let i = 0; i < ids.length; i += batchSize) {
    batches.push({
      batch_id: uuidv4(),
      ids: ids.slice(i, i + batchSize),
      status: 'yet_to_start',
      created_time: Date.now(),
      priority
    });
  }

  ingestions[ingestionId] = {
    ingestion_id: ingestionId,
    status: 'yet_to_start',
    batches
  };
}

function getIngestionStatus(ingestionId) {
  return ingestions[ingestionId];
}

function getPendingBatches() {
  let allBatches = [];
  for (let ingestion of Object.values(ingestions)) {
    for (let batch of ingestion.batches) {
      if (batch.status === 'yet_to_start') {
        allBatches.push({ ingestion, batch });
      }
    }
  }
  return allBatches;
}

function updateBatchStatus(batch, status) {
  batch.status = status;

  const ingestion = Object.values(ingestions).find(ing => ing.batches.includes(batch));
  const statuses = ingestion.batches.map(b => b.status);

  if (statuses.every(s => s === 'yet_to_start')) ingestion.status = 'yet_to_start';
  else if (statuses.every(s => s === 'completed')) ingestion.status = 'completed';
  else ingestion.status = 'triggered';
}

module.exports = { createIngestion, getIngestionStatus, getPendingBatches, updateBatchStatus };