const dataStore = require('./dataStore');

let intervalId;

function startProcessing() {
  intervalId = setInterval(async () => {
    const pendingBatches = dataStore.getPendingBatches();

    if (pendingBatches.length === 0) return;

    pendingBatches.sort((a, b) => {
      const priorityOrder = { 'HIGH': 1, 'MEDIUM': 2, 'LOW': 3 };
      if (priorityOrder[a.batch.priority] !== priorityOrder[b.batch.priority]) {
        return priorityOrder[a.batch.priority] - priorityOrder[b.batch.priority];
      }
      return a.batch.created_time - b.batch.created_time;
    });

    const nextBatch = pendingBatches[0];
    dataStore.updateBatchStatus(nextBatch.batch, 'triggered');

    await processBatch(nextBatch.batch);
    dataStore.updateBatchStatus(nextBatch.batch, 'completed');
  }, 5000);
}

function enqueueIngestion() {
  // processing happens automatically via startProcessing
}

async function processBatch(batch) {
  console.log(`Processing batch ${batch.batch_id}`);
  for (let id of batch.ids) {
    await simulateExternalFetch(id);
  }
}

function simulateExternalFetch(id) {
  return new Promise(resolve => {
    setTimeout(() => {
      console.log({ id, data: 'processed' });
      resolve();
    }, 1000);
  });
}

module.exports = { startProcessing, enqueueIngestion };